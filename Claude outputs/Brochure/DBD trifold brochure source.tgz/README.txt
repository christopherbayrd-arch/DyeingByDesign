DBD trifold brochure source (built 2026-09-11)
img/ is a copy of the site's public/images, plus img/cedar/IMG_3060.jpg (decoded from Chris's HEIC with /home/claude/cedar/heic2jpg.py; grade.py makes the gold/ink cedar tile).
  python3 prep.py     # crops/grades photos from img/ into out/, bakes the cover fade, makes qr.svg (OpenCV)
  python3 build.py    # template.html -> out/brochure_bleed.html, brochure_trim.html, brochure_guides.html
  node render.mjs     # Playwright/Chromium -> out/*.pdf + out/guides-page*.png (fold guides preview)
  python3 finish.py   # sets TrimBox/BleedBox + PDF metadata
Panels (inches): outside = flap 3.625 | back 3.6875 | front 3.6875 ; inside = 3.6875 | 3.6875 | 3.625 (tuck)
Letter file: inside page is rotated 180 (class "flip") so it prints right side up on Chris's home printer; print shop file stays upright.
Fonts: Poppins (system) + "Lora Print" static instances in out/fonts (variable Lora embeds as Type 3, avoid).
Text lives in template.html (prices, email, Instagram, copy).
