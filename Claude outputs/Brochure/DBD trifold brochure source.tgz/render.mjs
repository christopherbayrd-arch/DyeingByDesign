import { chromium } from "/home/claude/.npm-global/lib/node_modules/playwright/index.mjs";
import path from "node:path";
const dir = path.resolve("out");
const jobs = [
  { html: "brochure_bleed.html", pdf: "DBD-trifold-print-shop-bleed.pdf", w: 11.25, h: 8.75 },
  { html: "brochure_trim.html",  pdf: "DBD-trifold-letter.pdf",           w: 11,    h: 8.5 },
];
const b = await chromium.launch();
for (const j of jobs) {
  const p = await b.newPage();
  await p.goto("file://" + path.join(dir, j.html), { waitUntil: "load" });
  await p.evaluate(async () => { await document.fonts.ready; await Promise.all([...document.images].map(i => i.decode().catch(() => {}))); });
  // report any overflow: panels whose content is taller than the panel
  const over = await p.evaluate(() => [...document.querySelectorAll(".panel")].map(el => {
    const r = el.getBoundingClientRect();
    let maxB = 0; el.querySelectorAll("*").forEach(c => { if (c.classList.contains("band") || c.classList.contains("fern-wm")) return; const cr = c.getBoundingClientRect(); if (cr.height) maxB = Math.max(maxB, cr.bottom); });
    return { panel: el.className, panelBottomIn: +(r.bottom/96).toFixed(3), contentBottomIn: +(maxB/96).toFixed(3), slackIn: +((r.bottom - 0.38*96 - maxB)/96).toFixed(3) };
  }));
  console.log(j.pdf, JSON.stringify(over));
  await p.pdf({ path: path.join(dir, j.pdf), width: j.w + "in", height: j.h + "in", printBackground: true, preferCSSPageSize: true });
  await p.close();
}
// preview with fold guides
const p = await b.newPage({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 2 });
await p.goto("file://" + path.join(dir, "brochure_guides.html"), { waitUntil: "load" });
await p.evaluate(async () => { await document.fonts.ready; });
const sheets = await p.$$(".sheet");
let i = 1; for (const s of sheets) { await s.screenshot({ path: path.join(dir, `guides-page${i++}.png`) }); }
await b.close();
