from pypdf import PdfReader, PdfWriter
from pypdf.generic import RectangleObject
meta = {"/Title": "Dyeing By Design trifold brochure", "/Author": "Dyeing By Design",
        "/Subject": "Trifold brochure, letter size, 2 sided (outside, inside)", "/Creator": "Dyeing By Design"}
for name, bleed in (("DBD-trifold-letter.pdf", 0), ("DBD-trifold-print-shop-bleed.pdf", 9)):
    r = PdfReader(f"out/{name}"); w = PdfWriter()
    for pg in r.pages:
        mb = pg.mediabox
        W, H = float(mb.width), float(mb.height)
        pg.trimbox = RectangleObject([bleed, bleed, W - bleed, H - bleed])
        pg.bleedbox = RectangleObject([0, 0, W, H])
        pg.cropbox = RectangleObject([0, 0, W, H])
        w.add_page(pg)
    w.add_metadata(meta)
    with open(f"out/{name}", "wb") as f: w.write(f)
    r2 = PdfReader(f"out/{name}")
    p = r2.pages[0]
    print(name, "media", [float(x) for x in p.mediabox], "trim", [float(x) for x in p.trimbox], "pages", len(r2.pages))
