"""Minimal HEIC -> JPEG for iPhone photos without libheif/pillow-heif.
Parses the HEIF boxes, pulls the HEVC tiles of the primary (grid) image, decodes them with
ffmpeg's HEVC decoder, stitches the grid, applies clap/irot/imir, converts the ICC (Display P3) to sRGB."""
import struct, subprocess, sys, os, io, tempfile, glob
from PIL import Image, ImageCms

def boxes(buf, off=0, end=None):
    end = len(buf) if end is None else end
    while off + 8 <= end:
        size, typ = struct.unpack('>I4s', buf[off:off+8]); hdr = 8
        if size == 1: size = struct.unpack('>Q', buf[off+8:off+16])[0]; hdr = 16
        elif size == 0: size = end - off
        yield typ.decode('latin1'), off + hdr, off + size
        off += size

def uint(b, n): return int.from_bytes(b[:n], 'big') if n else 0

def parse(path):
    buf = open(path, 'rb').read()
    top = {t: (s, e) for t, s, e in boxes(buf)}
    ms, me = top['meta']; ms += 4                      # FullBox header
    meta = {t: (s, e) for t, s, e in boxes(buf, ms, me)}
    # pitm
    s, e = meta['pitm']; v = buf[s]; primary = uint(buf[s+4:], 2 if v == 0 else 4)
    # iinf
    s, e = meta['iinf']; v = buf[s]; p = s + 4 + (2 if v == 0 else 4)
    items = {}
    for t, bs, be in boxes(buf, p, e):
        if t != 'infe': continue
        iv = buf[bs]; q = bs + 4
        if iv >= 2:
            iid = uint(buf[q:], 2 if iv == 2 else 4); q += 2 if iv == 2 else 4
            q += 2; itype = buf[q:q+4].decode('latin1'); items[iid] = itype
    # iloc
    s, e = meta['iloc']; v = buf[s]; q = s + 4
    a, b = buf[q], buf[q+1]; q += 2
    osz, lsz, bosz, isz = a >> 4, a & 15, b >> 4, (b & 15 if v in (1, 2) else 0)
    cnt = uint(buf[q:], 2 if v < 2 else 4); q += 2 if v < 2 else 4
    iloc = {}
    for _ in range(cnt):
        iid = uint(buf[q:], 2 if v < 2 else 4); q += 2 if v < 2 else 4
        cm = 0
        if v in (1, 2): cm = uint(buf[q:], 2) & 15; q += 2
        q += 2                                            # data_reference_index
        base = uint(buf[q:], bosz); q += bosz
        ec = uint(buf[q:], 2); q += 2; ext = []
        for _ in range(ec):
            q += isz
            eo = uint(buf[q:], osz); q += osz; el = uint(buf[q:], lsz); q += lsz
            ext.append((base + eo, el))
        iloc[iid] = (cm, ext)
    idat = meta.get('idat')
    def data(iid):
        cm, ext = iloc[iid]
        src_off = idat[0] if cm == 1 else 0
        return b''.join(buf[src_off+o:src_off+o+l] for o, l in ext)
    # iref
    refs = {}
    if 'iref' in meta:
        s, e = meta['iref']; v = buf[s]; w = 2 if v == 0 else 4
        for t, bs, be in boxes(buf, s + 4, e):
            q = bs; frm = uint(buf[q:], w); q += w; n = uint(buf[q:], 2); q += 2
            refs.setdefault((t, frm), []).extend(uint(buf[q+i*w:], w) for i in range(n))
    # iprp: ipco + ipma
    s, e = meta['iprp']; sub = {t: (a2, b2) for t, a2, b2 in boxes(buf, s, e)}
    props = [(t, bs, be) for t, bs, be in boxes(buf, *sub['ipco'])]
    ps, pe = sub['ipma']; v = buf[ps]; fl = uint(buf[ps+1:], 3); q = ps + 4
    n = uint(buf[q:], 4); q += 4; assoc = {}
    for _ in range(n):
        iid = uint(buf[q:], 2 if v < 1 else 4); q += 2 if v < 1 else 4
        c = buf[q]; q += 1; lst = []
        for _ in range(c):
            if fl & 1: idx = uint(buf[q:], 2) & 0x7fff; q += 2
            else: idx = buf[q] & 0x7f; q += 1
            if idx: lst.append(props[idx - 1])
        assoc[iid] = lst
    return buf, primary, items, data, refs, assoc

def hvcc_params(buf, bs, be):
    rec = buf[bs:be]
    lsize = (rec[21] & 3) + 1; narr = rec[22]; q = 23; nals = []
    for _ in range(narr):
        q += 1; nn = uint(rec[q:], 2); q += 2
        for _ in range(nn):
            ln = uint(rec[q:], 2); q += 2; nals.append(rec[q:q+ln]); q += ln
    return lsize, nals

def to_annexb(sample, lsize):
    out = bytearray(); q = 0
    while q < len(sample):
        ln = uint(sample[q:], lsize); q += lsize
        out += b'\x00\x00\x00\x01' + sample[q:q+ln]; q += ln
    return bytes(out)

def convert(path, out_jpg, quality=95):
    buf, primary, items, data, refs, assoc = parse(path)
    pid = primary
    if items.get(pid) == 'tmap':                        # iOS 18 gain map wrapper: use the base image
        pid = refs[('dimg', pid)][0]
    ptype = items[pid]
    if ptype == 'grid':
        g = data(pid); flags = g[1]; rows, cols = g[2] + 1, g[3] + 1
        w = 4 if flags & 1 else 2
        ow, oh = uint(g[4:], w), uint(g[4+w:], w)
        tiles = refs[('dimg', pid)]
    elif ptype == 'hvc1':
        rows = cols = 1; tiles = [pid]; ow = oh = None
    else:
        raise SystemExit(f"unsupported primary item type {ptype}")
    # decoder config from the first tile
    hv = [p for p in assoc[tiles[0]] if p[0] == 'hvcC'][0]
    lsize, params = hvcc_params(buf, hv[1], hv[2])
    ps = b''.join(b'\x00\x00\x00\x01' + n for n in params)
    stream = b''.join(ps + to_annexb(data(t), lsize) for t in tiles)
    with tempfile.TemporaryDirectory() as td:
        open(f"{td}/s.hevc", 'wb').write(stream)
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'hevc', '-i', f"{td}/s.hevc",
                        '-fps_mode', 'passthrough', '-pix_fmt', 'rgb24', f"{td}/t%04d.png"], check=True)
        fr = sorted(glob.glob(f"{td}/t*.png"))
        assert len(fr) == len(tiles), (len(fr), len(tiles))
        t0 = Image.open(fr[0]); tw, th = t0.size
        canvas = Image.new('RGB', (cols * tw, rows * th))
        for i, f in enumerate(fr):
            canvas.paste(Image.open(f).convert('RGB'), ((i % cols) * tw, (i // cols) * th))
    im = canvas.crop((0, 0, ow, oh)) if ow else canvas
    icc = None
    for t, bs, be in assoc[pid]:
        if t == 'colr' and buf[bs:bs+4] in (b'prof', b'rICC'): icc = buf[bs+4:be]
        elif t == 'clap':
            vals = struct.unpack('>8i', buf[bs:bs+32])
            cw, ch = vals[0] / vals[1], vals[2] / vals[3]
            hx, hy = vals[4] / vals[5], vals[6] / vals[7]
            cx, cy = (im.width - 1) / 2 + hx, (im.height - 1) / 2 + hy
            im = im.crop((round(cx - (cw - 1) / 2), round(cy - (ch - 1) / 2), round(cx - (cw - 1) / 2) + round(cw), round(cy - (ch - 1) / 2) + round(ch)))
        elif t == 'irot':
            ang = buf[bs] & 3
            if ang: im = im.transpose({1: Image.ROTATE_90, 2: Image.ROTATE_180, 3: Image.ROTATE_270}[ang])
        elif t == 'imir':
            im = im.transpose(Image.FLIP_TOP_BOTTOM if (buf[bs] & 1) == 0 else Image.FLIP_LEFT_RIGHT)
    if icc:
        try:
            src = ImageCms.ImageCmsProfile(io.BytesIO(icc)); dst = ImageCms.createProfile('sRGB')
            im = ImageCms.profileToProfile(im, src, dst, renderingIntent=0, outputMode='RGB')
        except Exception as ex:
            print("ICC convert skipped:", ex)
    im.save(out_jpg, quality=quality, subsampling=0)
    return im.size, ptype, rows, cols, bool(icc)

if __name__ == '__main__':
    for p in sys.argv[1:]:
        name = os.path.basename(p).split('-', 1)[-1].rsplit('.', 1)[0] + '.jpg'
        print(name, convert(p, os.path.join('/home/claude/cedar', name)))
