import sys
COLORS = [("Black","#141414"),("Antique cherry red","#9a1c2e"),("Azalea","#f28cb1"),("Daisy","#f6c945"),
          ("Electric green","#3ddc3a"),("Forest green","#1f4d2e"),("Sky blue","#7fb8e6"),("Royal blue","#1f4fa3"),("Purple","#4a2d7e")]
names = " · ".join(n.replace(" ", "&nbsp;") for n,_ in COLORS)
sw = "".join(f'<span style="background:{h}" title="{n}"></span>' for n,h in COLORS)
t = open("template.html").read().replace("%%SWATCHES%%", sw).replace("%%SWATCHNAMES%%", names)
def variant(name, bleed, guides=False, preview=False, flip=False):
    pw, ph = 11 + 2*bleed, 8.5 + 2*bleed
    h = (t.replace("%%PW%%", f"{pw:g}").replace("%%PH%%", f"{ph:g}").replace("%%B%%", f"{bleed:g}")
          .replace("%%GUIDES%%", "block" if guides else "none")
          .replace("%%BODYBG%%", "#8a8a8a" if preview else "#ffffff")
          .replace("%%SHEETGAP%%", "0 0 24px 0" if preview else "0")
          .replace("%%INSIDEFLIP%%", "flip" if flip else ""))
    open(f"out/{name}.html","w").write(h)
variant("brochure_bleed", 0.125)
variant("brochure_trim", 0.0, flip=True)
variant("brochure_guides", 0.0, guides=True, preview=True)
print("ok")
