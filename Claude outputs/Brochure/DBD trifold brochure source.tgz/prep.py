"""Prepare print images for the DBD tri-fold: crops, grading, baked fades, QR."""
from PIL import Image, ImageFilter, ImageOps, ImageEnhance, ImageDraw
import numpy as np, cv2, os

SRC = "img"
OUT = "out"
INK = (25, 20, 8)
DPI = 300

def save(im, name, q=90):
    p = os.path.join(OUT, name)
    im.convert("RGB").save(p, quality=q, subsampling=0, dpi=(DPI, DPI))
    return p

def crop_to(im, box, out_w_in, out_h_in, max_dpi=330):
    """crop box (l,t,r,b) then resize so placed size is <= max_dpi (never upscale)."""
    c = im.crop(box)
    tw = int(round(out_w_in * max_dpi)); th = int(round(out_h_in * max_dpi))
    if c.width > tw:
        c = c.resize((tw, int(round(c.height * tw / c.width))), Image.LANCZOS)
    return c

# ---------------- cover band (baked fades + halo) ----------------
EXT = 0.125                     # bleed extension used by the layout
BAND_W = 3.6875 + EXT           # panel width + right bleed
BAND_TOP = -EXT
BAND_BOT = 5.55                 # trim coords
BAND_H = BAND_BOT - BAND_TOP
LOGO_CX = 3.6875 / 2            # panel-local
LOGO_CY = 3.2
LOGO_D = 2.55

hero = Image.open(f"{SRC}/hero-texture.jpg").convert("RGB")
aspect = BAND_W / BAND_H
ch = 1127; cw = int(round(ch * aspect))
x0 = 170; y0 = 200
band = hero.crop((x0, y0, x0 + cw, y0 + ch))
W = int(round(BAND_W * DPI)); H = int(round(BAND_H * DPI))
band = band.resize((W, H), Image.LANCZOS)
band = ImageEnhance.Contrast(band).enhance(1.06)
a = np.asarray(band).astype(np.float32)
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
yin = yy / DPI + BAND_TOP        # trim-coord inches
xin = xx / DPI
ink = np.array(INK, np.float32)
def smooth(t):
    t = np.clip(t, 0, 1); return t * t * (3 - 2 * t)
# darkness map: 0 = photo, 1 = ink
d = np.zeros((H, W), np.float32)
d = np.maximum(d, 0.28 * (1 - smooth((yin - 0.0) / 1.2)))            # soft top
d = np.maximum(d, smooth((yin - 3.9) / (BAND_BOT - 0.05 - 3.9)))     # bottom fade to ink
d = np.maximum(d, 1 - smooth((xin - 0.0) / 0.42))                    # left edge (fold) fade
# halo behind the logo
r = np.sqrt((xin - LOGO_CX) ** 2 + (yin - LOGO_CY) ** 2)
halo = 0.62 * (1 - smooth((r - LOGO_D / 2 + 0.05) / 0.75))
d = np.maximum(d, halo)
d = np.maximum(d, 0.12)                                              # overall slight dim
out = a * (1 - d[..., None]) + ink * d[..., None]
save(Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)), "cover-band.jpg", q=92)

# ---------------- logo (keep alpha) ----------------
logo = Image.open(f"{SRC}/logo.png").convert("RGBA")
logo.save(f"{OUT}/logo.png")

# ---------------- color tiles (P1) ----------------
TILE_ASPECT = 0.87
tiles = {
    "tile-cherry.jpg":   ("recent/sumac-cherry.jpg",   860),
    "tile-sky.jpg":      ("recent/sumac-sky.jpg",      790),
    "tile-forest.jpg":   ("recent/sumac-forest.jpg",   850),
    "tile-electric.jpg": ("recent/sumac-electric.jpg", 865),
    "tile-daisy.jpg":    ("recent/sumac-daisy.jpg",    850),
    "tile-black.jpg":    ("recent/sumac-flat.jpg",     865),
}
for name, (src, cy) in tiles.items():
    im = Image.open(f"{SRC}/{src}").convert("RGB")
    w = im.width; h = int(round(w / TILE_ASPECT))
    t = max(0, min(im.height - h, cy - h // 2))
    save(crop_to(im, (0, t, w, t + h), 1.46, 1.46 / TILE_ASPECT), name, q=90)

# ---------------- maker (P2) ----------------
im = Image.open(f"{SRC}/recent/fern-worn.jpg").convert("RGB")
im = ImageEnhance.Brightness(im).enhance(1.06)
save(crop_to(im, (190, 240, 1170, 1145), 3.09, 2.85), "maker.jpg")

# ---------------- gathering (P4) ----------------
im = Image.open(f"{SRC}/recent/gathering-sumac.jpg").convert("RGB")
save(crop_to(im, (0, 150, 1200, 1083), 3.09, 2.4), "gather.jpg")

# ---------------- lineup photos (P5) ----------------
im = Image.open(f"{SRC}/detail.jpg").convert("RGB")
save(crop_to(im, (130, 250, 700, 1020), 1.49, 2.01), "line-sumac.jpg")
im = Image.open(f"{SRC}/design-fern.jpg").convert("RGB")
save(crop_to(im, (160, 70, 940, 1124), 1.49, 2.01), "line-fern.jpg")
im = Image.open(f"{SRC}/recent/fern-flat.jpg").convert("RGB")
save(crop_to(im, (0, 440, 1200, 1060), 3.03, 1.57), "strip-fern.jpg")

# ---------------- cedar (added 2026-09-11 when Oak was dropped) ----------------
from grade import grade, warm
cedar_src = Image.open(f"{SRC}/cedar/IMG_3060.jpg").convert("RGB")   # purple blank, cedar sprigs
# lineup tile: same gold/ink grade as the site card, portrait crop for the P5 duo
save(warm(grade(cedar_src.crop((1082, 1350, 2118, 2750)).resize((492, 665), Image.LANCZOS))), "line-cedar.jpg")
# colors panel tile: real color, whole shirt (crop keeps the photographer's shoe out)
def color_recipe(im, size):
    im = im.resize(size, Image.LANCZOS)
    im = ImageEnhance.Contrast(im).enhance(1.08); im = ImageEnhance.Color(im).enhance(1.04)
    w, h = im.size
    m = Image.new("L", (w, h), 0); ImageDraw.Draw(m).ellipse((-w * .08, -h * .06, w * 1.08, h * 1.06), fill=255)
    m = m.filter(ImageFilter.GaussianBlur(220 * w / 1200))
    return Image.composite(im, Image.eval(im, lambda v: int(v * 0.72)), m)
save(color_recipe(cedar_src.crop((225, 558, 2925, 3661)), (482, 554)), "tile-purple.jpg")

# ---------------- QR (vector SVG) ----------------
p = cv2.QRCodeEncoder_Params(); p.correction_level = cv2.QRCODE_ENCODER_CORRECT_LEVEL_Q
url = "https://www.dyeingbydesign.com"
m = cv2.QRCodeEncoder_create(p).encode(url)
ys, xs = np.where(m == 0)
m = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]   # strip the encoder's quiet zone
n = m.shape[0]
rects = []
for y in range(n):
    x = 0
    while x < n:
        if m[y, x] == 0:
            x1 = x
            while x1 < n and m[y, x1] == 0: x1 += 1
            rects.append(f'<rect x="{x}" y="{y}" width="{x1-x}" height="1.02"/>')
            x = x1
        else:
            x += 1
svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges"><g fill="#191408">{"".join(rects)}</g></svg>'
open(f"{OUT}/qr.svg", "w").write(svg)
print("qr modules", n)

# ---------------- ornaments ----------------
leaf = open(f"{SRC}/leaf-mark.svg").read()
open(f"{OUT}/leaf-gold.svg", "w").write(leaf.replace("#c98d45", "#cf9440"))
open(f"{OUT}/leaf-rust.svg", "w").write(leaf.replace("#c98d45", "#a8622a"))
fern = open(f"{SRC}/fern-mark.svg").read()
open(f"{OUT}/fern-gold.svg", "w").write(fern)
for f in sorted(os.listdir(OUT)):
    fp = os.path.join(OUT, f)
    if f.endswith(".jpg"):
        im = Image.open(fp); print(f, im.size, os.path.getsize(fp)//1024, "KB")
