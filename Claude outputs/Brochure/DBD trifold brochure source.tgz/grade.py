"""Grade a colored cedar shirt crop into the lineup cards' gold/ink look by
borrowing the fern card's tone curve + color-per-luminance from design-fern.jpg."""
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

REF = "/home/claude/brochure/img/design-fern.jpg"

def lum(a):
    return 0.299 * a[..., 0] + 0.587 * a[..., 1] + 0.114 * a[..., 2]

def ref_tables():
    r = np.asarray(Image.open(REF).convert("RGB")).astype(np.float32)
    # ignore the baked vignette edge a bit: use the central 80%
    h, w = r.shape[:2]; r = r[int(h*.1):int(h*.9), int(w*.1):int(w*.9)]
    L = lum(r).ravel(); rgb = r.reshape(-1, 3)
    idx = np.clip(L.round().astype(int), 0, 255)
    lut = np.zeros((256, 3)); cnt = np.bincount(idx, minlength=256).astype(float)
    for c in range(3):
        lut[:, c] = np.bincount(idx, weights=rgb[:, c], minlength=256)
    have = cnt > 20
    xs = np.arange(256)
    for c in range(3):
        lut[:, c] = np.interp(xs, xs[have], lut[have, c] / cnt[have])
    # smooth the lut
    k = np.ones(9) / 9
    for c in range(3):
        lut[:, c] = np.convolve(np.pad(lut[:, c], 4, mode="edge"), k, mode="valid")
    sortedL = np.sort(L)
    return lut, sortedL

LUT, REFL = ref_tables()

def grade(img, contrast_gamma=1.0, vignette=True):
    a = np.asarray(img.convert("RGB")).astype(np.float32)
    L = lum(a)
    # histogram match luminance to the fern card
    flat = L.ravel(); order = np.argsort(flat)
    ranks = np.empty_like(order); ranks[order] = np.arange(flat.size)
    q = ranks / (flat.size - 1)
    Lm = np.interp(q, np.linspace(0, 1, REFL.size), REFL).reshape(L.shape)
    if contrast_gamma != 1.0:
        Lm = 255 * (Lm / 255) ** contrast_gamma
    out = np.stack([np.interp(Lm, np.arange(256), LUT[:, c]) for c in range(3)], -1)
    im = Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))
    if vignette:
        w, h = im.size
        m = Image.new("L", (w, h), 0)
        ImageDraw.Draw(m).ellipse((-w * .12, -h * .12, w * 1.12, h * 1.12), fill=255)
        m = m.filter(ImageFilter.GaussianBlur(w * 0.18))
        dark = Image.eval(im, lambda v: int(v * 0.72))
        im = Image.composite(im, dark, m)
    return im.filter(ImageFilter.UnsharpMask(radius=1.5, percent=60, threshold=2))

def warm(im, gain=(1.03, 1.0, 0.93), gamma=1.06):
    """Nudge the graded cedar toward the amber of the sumac/fern cards."""
    a = np.asarray(im.convert("RGB")).astype(np.float32) / 255.0
    a = (a ** gamma) * np.array(gain)
    return Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8))
